import reactPic from "../../assets/react-core-concepts.png";
import "./Title.css";

const reactDescriptions = ["Fundamental", "Crucial", "Core"];

function getRandomInt(max) {
  return Math.floor(Math.random() * (max + 1));
}

export default function Title() {
  const descriptions = reactDescriptions[getRandomInt(2)];
  return (
    <header>
      <img src={reactPic} alt="Stylized atom" />
      <h1>Pranay Nair - Professional Skills </h1>
      <p>{descriptions} Skils about me</p>
    </header>
  );
}
